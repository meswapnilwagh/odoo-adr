#-*- coding: utf-8 -*-
from openerp.osv import orm, fields
from openerp.osv.orm import except_orm

class ProductCategory(orm.Model):

    _inherit = 'product.category'
    _columns = {
        'code': fields.char('Category code',
                            required=True,
                            size=5),
        'sequence_id': fields.many2one('ir.sequence',
                                       'Category sequence',
                                       required=True)
    }
    
    def create(self, cr, uid, vals, context=None):
        if not context:
            context = context
        created_id = super(ProductCategory, self).create(cr, uid, vals, context=context)
        seq_id = self.get_created_seq_id(cr, uid, created_id, context)
        self.write(cr, uid, created_id, {'sequence_id': seq_id}, context)
        return created_id

    def get_created_seq_id(self, cr, uid, product_category_id, context=None):
        category_name = self.pool.get('product.category').browse(cr, uid, product_category_id, context).name
        sequence = self.pool.get('ir.sequence')
        created_seq_id = sequence.create(cr, uid, {
            'name': 'Code {0}'.format(category_name),
            'active': True,
            'code': 'product.category.code',
            'padding': 5,
            'number_increment': 1,
            'next_number': 1,
            'implementation': 'no_gap'}, context)
        return created_seq_id
     
ProductCategory()


class Product(orm.Model):

    _inherit = 'product.product'

    def get_category_code(self, cr, uid, ids, context=None):
        category_obj = self.pool.get('product.category')
        seq_obj = self.pool.get('ir.sequence')
        for product in self.browse(cr, uid, ids, context):
            category = product.categ_id.id
            name = category_obj.browse(cr, uid, category, context).name
            code = category_obj.browse(cr, uid, category, context).code
            seq_id = seq_obj.search(cr, uid, [('name', '=', 'Code {0}'.format(name))])
            if code and seq_id:
                seq_number = seq_obj.get_id(cr, uid, seq_id[0])
                seq_number = seq_number.strip()
                res = {product.id: code + seq_number}
            else:
                res = {product.id: False}
        return res

    def create(self, cr, uid, vals, context=None):
        if not context:
            context = context
        created_id = super(Product, self).create(cr, uid, vals, context)
        code = self.get_category_code(cr, uid, [created_id], context)
        self.write(cr, uid, created_id, {'default_code': code.get(created_id)}, context)
        return created_id

    def write(self, cr, uid, ids, values, context=None):
        sequence = self.pool.get('ir.sequence')
        product_category = self.pool.get('product.category')
        product = self.pool.get('product.product')
        product_ids = product.search(cr, uid, [('default_sale','=',True)])
        if values.has_key('categ_id'):
            category = product_category.browse(cr, uid, values['categ_id'], context)
            category_name = category.name
            category_code = category.code
            new_seq_id = sequence.search(cr, uid, [('name', '=', 'Code {0}'.format(category_name))])
            new_sequence = sequence.get_id(cr, uid, new_seq_id[0])
            new_sequence = new_sequence.strip()
            new_sequence = category_code + new_sequence
            values['default_code'] = new_sequence
        
        super(Product, self).write(cr, uid, ids, values, context)
        return True

    _columns = {
        'default_code': fields.char('Internal reference', size=10),
    }
