#-*- coding: utf-8 -*-
from openerp.osv import orm, fields
from openerp.osv.orm import except_orm


class res_company(orm.Model):

    _inherit = 'res.company'
    _columns = {
        'code': fields.char('Company Code',
                            required=False,
                            size=5),
    }
